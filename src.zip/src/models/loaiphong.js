class LoaiPhong {
    constructor(MaLoaiPhong, DienTich, SoKhachToiDa, TenLoaiPhong, Gia, MoTa) {
        this.MaLoaiPhong = MaLoaiPhong;
        this.DienTich = DienTich;
        this.SoKhachToiDa = SoKhachToiDa;
        this.TenLoaiPhong = TenLoaiPhong;
        this.Gia = Gia;
        this.MoTa = MoTa;
    }
}

module.exports = LoaiPhong;
